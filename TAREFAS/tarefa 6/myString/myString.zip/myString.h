
char *strcpy(char *s1, const char *s2);

char *strncpy(char *s1, const char *s2, int n);

char *strcat(char *s1, const char *s2);

char *strncat(char *s1, const char *s2, int n);

int strcmp(const char *s1, const char *s2);

int strncmp(const char *s1, const char *s2, int n);